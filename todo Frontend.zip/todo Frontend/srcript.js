var SERVER_URL = "http://localhost:8080";
var token = localStorage.getItem("token");
var email = localStorage.getItem("email");
function register(){
    let a  = document.getElementById("email").value;
    let b = document.getElementById("password").value;
    
    fetch(`${SERVER_URL}/auth/register`,{
        method: "POST",
        headers: {"Content-Type":"application/json"},
        body: JSON.stringify({email:a,password:b})
    })
    .then(response=>{
        if(response.ok){
            alert("Registration Successfull")
            window.location.href ="login.html"
        }
        else{
            return response.json().then(data=>{throw new Error(data.message || "Registration Failed") })
        }
    })
    .catch(error =>{
        alert(error.message)
    })
        
}
function del(event){
    let id = event.target.dataset.id;
    fetch(`${SERVER_URL}/todo/delete?id=${id}`,{
        method: "DELETE",
        headers: {"Content-Type":"application/json","Authorization":"Bearer "+token},
    })
    .then(response=>{
        if(!response.ok){
            throw new Error("Delete Failed");
            
        }
        event.target.parentElement.remove();
    })
    .catch(error=>{
        alert(error.message)
    })

}
function login(){
    let a  = document.getElementById("email").value;
    let b = document.getElementById("password").value;
    localStorage.setItem("email",a);
    fetch(`${SERVER_URL}/auth/login`,{
        method: "POST",
        headers: {"Content-Type": "application/json"},
        body: JSON.stringify({email: a,password: b})
    })
    .then(response => {
        if(!response.ok){
            throw new Error("Login Failed");
        }
        return response.json();
    })
    .then(data =>{
        localStorage.setItem("token",data.token);
        window.location.href = "todos.html";
    })
    .catch(error=>{
        alert(error.message);
    }); 
        
}
function update(event){
    let a = event.target.dataset.id;
    let b = event.target.checked;
    fetch(`${SERVER_URL}/todo/update?id=${a}`,
        {
            method: "PUT",
            headers: {"Content-Type": "application/json","Authorization":"Bearer "+token},
            body: JSON.stringify({id: a,isCompleted: b})
        }
    )
    .then(response=>{
        if(!response.ok){
            throw new Error("Update failed");
        }
        alert("updated");
    })
    .catch(error=>{
        alert(error.message);
    }
        
    )
}

function add(){
    let a = document.getElementById("todo").value;
    let b = document.createElement("div");
    let c = document.getElementById("main");
    let checkbox = document.createElement("input")
    b.style.display = "flex";
    b.style.alignItems = "center";
    b.style.justifyContent = "space-between";
    b.style.width = "80%";
    checkbox.type = "checkbox";
    let deletbtn = document.createElement("button")
    let text = document.createElement("span")
    text.textContent = a;
    deletbtn.textContent = "X";
    deletbtn.style.borderRadius = "10px";
    deletbtn.style.backgroundColor = "red";
    deletbtn.style.color = "white";
    deletbtn.style.borderRadius = "10px";
    deletbtn.addEventListener("click",del);
    checkbox.addEventListener("change",update);
    checkbox.style.width = "25px";
    checkbox.style.height = "25px";
    deletbtn.style.width = "30px";
    deletbtn.style.height = "30px";
    b.append(checkbox);
    b.append(text);
    b.append(deletbtn);
    c.append(b);
    fetch(`${SERVER_URL}/todo/create`,{
        method: "POST",
        headers: {"Content-Type": "application/json","Authorization": "Bearer "+ token},
        body : JSON.stringify({title: a,isCompleted: false,email: email})
    })
    .then(response =>{
        if(!response.ok){
            throw new Error("Todo failed");
        }
        return response.json();
        
    })
    .then(data =>{
        deletbtn.dataset.id = data.id;
        checkbox.dataset.id = data.id;
    })
    .catch(error=>{
        alert(error.message);
    })
}

function display(event){
    let c = document.getElementById("main");
    fetch(`${SERVER_URL}/todo/get`,{
        method: "GET",
        headers: {"Content-Type": "application/json","Authorization": "Bearer "+token},
    })
    .then(response=>{
        if(!response.ok){
            console.log(response.status);
            throw new Error("Failed to load Todos")
        }
        return response.json();
    })
    .then(data =>{
        for(var items of data){
            let b = document.createElement("div");
            let checkbox = document.createElement("input")
            b.style.display = "flex";
            b.style.alignItems = "center";
            b.style.justifyContent = "space-between";
            b.style.width = "80%";
            checkbox.type = "checkbox";
            let deletbtn = document.createElement("button")
            let text = document.createElement("span")
            checkbox.checked = items.isCompleted;
            text.textContent = items.title;
            deletbtn.textContent = "X";
            deletbtn.dataset.id=items.id;
            deletbtn.style.borderRadius = "10px";
            deletbtn.style.backgroundColor = "red";
            deletbtn.style.color = "white";
            deletbtn.style.borderRadius = "10px";
            deletbtn.addEventListener("click",del);
            checkbox.addEventListener("change",update);
            checkbox.style.width = "25px";
            checkbox.style.height = "25px";
            deletbtn.style.width = "30px";
            deletbtn.style.height = "30px";
            checkbox.dataset.id = items.id;
            checkbox.checked = items.isCompleted;
            b.append(checkbox);
            b.append(text);
            b.append(deletbtn);
            c.append(b);

        }
    })
    .catch(error=>{
        alert(error.message);
    })
}
var d = document.getElementById("main")
if(d){
    display();
}
