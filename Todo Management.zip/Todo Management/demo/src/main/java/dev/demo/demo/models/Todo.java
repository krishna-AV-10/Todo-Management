package dev.demo.demo.models;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Data;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Email;
@Entity
@Data
public class Todo{
    @Id
    @GeneratedValue
    Long id;
    @NotBlank
    String title;
    Boolean isCompleted;
    @Email
    String email;
}
