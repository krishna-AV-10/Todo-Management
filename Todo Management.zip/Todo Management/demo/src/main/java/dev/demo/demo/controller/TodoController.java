package dev.demo.demo.controller;

import dev.demo.demo.service.TodoService;
import dev.demo.demo.models.Todo;
import org.springframework.context.annotation.Bean;
import org.springframework.data.domain.Page;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/todo")
public class TodoController {
    @Autowired
    TodoService todoService;
    @GetMapping("/get")
    ResponseEntity<List<Todo>> getAlltodos(){
        return new ResponseEntity<>(todoService.getAll(), HttpStatus.OK);
    }

    @PostMapping("/create")
    ResponseEntity<Todo> createuser(@RequestBody Todo todo){
        return new ResponseEntity<>(todoService.createTodo(todo), HttpStatus.CREATED);
    }
    @PutMapping("/update")
    ResponseEntity<Void> updateTodo(@RequestParam Long id,@RequestBody Todo todo){
        todoService.updatetodo(id,todo.getIsCompleted());
        return new ResponseEntity<>(HttpStatus.OK);
    }
    @DeleteMapping("/delete")
    ResponseEntity<Void> deletetodoId(@RequestParam Long id){
        todoService.deletetodo(id);
        return new ResponseEntity<>(HttpStatus.OK);
    }
    @GetMapping("/page")
    ResponseEntity<Page<Todo>> getTodosPages(@RequestParam int page,@RequestParam int size){
        return new ResponseEntity<>(todoService.getAllTodosPages(page,size), HttpStatus.OK);
    }
}
