package dev.demo.demo;

import dev.demo.demo.service.TodoService;

public class Main {
    static void main(String[] args) {
        TodoService todoService = new TodoService();
    }
}
