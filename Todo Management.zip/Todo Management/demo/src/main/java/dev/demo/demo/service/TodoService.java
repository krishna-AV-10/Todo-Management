package dev.demo.demo.service;

import dev.demo.demo.models.Todo;
import dev.demo.demo.repository.TodoRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;


@Service
public class TodoService {
    @Autowired
    private TodoRepository todoRepository;

    public Todo createTodo(Todo todo){
        return todoRepository.save(todo);
    }
    public Todo getTodo(Long id){
        return todoRepository.getReferenceById(id);
    }
    public Page<Todo> getAllTodosPages(int page,int size){
        Pageable pageable = PageRequest.of(page, size);
        return todoRepository.findAll(pageable);
    }
    public List<Todo> getAll(){
        return todoRepository.findAll();
    }
    public Todo updateTodo(Todo todo){
        return todoRepository.save(todo);
    }
    public void deletetodo(Long id){
        todoRepository.deleteById(id);
    }

    public void updatetodo(Long id,boolean isCompleted){
        Todo odo = todoRepository.getById(id);
        odo.setIsCompleted(isCompleted);
        todoRepository.save(odo);
    }
}
